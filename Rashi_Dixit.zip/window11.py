# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'window11.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
import sqlite3
import sys

class Ui_MainWindow(object):
    bat,bow,ar,wk,avail,used=0,0,0,0,1000,0
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label1 = QtWidgets.QLabel(self.centralwidget)
        self.label1.setGeometry(QtCore.QRect(10, 0, 121, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label1.setFont(font)
        self.label1.setObjectName("label1")
        self.label2 = QtWidgets.QLabel(self.centralwidget)
        self.label2.setGeometry(QtCore.QRect(20, 40, 131, 16))
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(False)
        font.setWeight(50)
        self.label2.setFont(font)
        self.label2.setObjectName("label2")
        self.label3 = QtWidgets.QLabel(self.centralwidget)
        self.label3.setGeometry(QtCore.QRect(210, 40, 121, 16))
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(False)
        font.setWeight(50)
        self.label3.setFont(font)
        self.label3.setObjectName("label3")
        self.label4 = QtWidgets.QLabel(self.centralwidget)
        self.label4.setGeometry(QtCore.QRect(400, 40, 151, 16))
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(False)
        font.setWeight(50)
        self.label4.setFont(font)
        self.label4.setObjectName("label4")
        self.label5 = QtWidgets.QLabel(self.centralwidget)
        self.label5.setGeometry(QtCore.QRect(600, 40, 131, 16))
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(False)
        font.setWeight(50)
        self.label5.setFont(font)
        self.label5.setObjectName("label5")
        self.label6 = QtWidgets.QLabel(self.centralwidget)
        self.label6.setGeometry(QtCore.QRect(50, 110, 101, 16))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.label6.setFont(font)
        self.label6.setObjectName("label6")
        self.label7 = QtWidgets.QLabel(self.centralwidget)
        self.label7.setGeometry(QtCore.QRect(450, 110, 71, 16))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.label7.setFont(font)
        self.label7.setObjectName("label7")
        self.groupbox1 = QtWidgets.QGroupBox(self.centralwidget)
        self.groupbox1.setGeometry(QtCore.QRect(50, 150, 301, 391))
        self.groupbox1.setTitle("")
        self.groupbox1.setObjectName("groupbox1")
        self.rb1 = QtWidgets.QRadioButton(self.groupbox1)
        self.rb1.setGeometry(QtCore.QRect(20, 20, 82, 17))
        self.rb1.setObjectName("rb1")
        self.rb2 = QtWidgets.QRadioButton(self.groupbox1)
        self.rb2.setGeometry(QtCore.QRect(90, 20, 82, 17))
        self.rb2.setObjectName("rb2")
        self.rb3 = QtWidgets.QRadioButton(self.groupbox1)
        self.rb3.setGeometry(QtCore.QRect(160, 20, 82, 17))
        self.rb3.setObjectName("rb3")
        self.rb4 = QtWidgets.QRadioButton(self.groupbox1)
        self.rb4.setGeometry(QtCore.QRect(230, 20, 81, 16))
        self.rb4.setObjectName("rb4")
        self.list1 = QtWidgets.QListWidget(self.groupbox1)
        self.list1.setGeometry(QtCore.QRect(20, 50, 261, 321))
        self.list1.setObjectName("list1")
        self.groupbox2 = QtWidgets.QGroupBox(self.centralwidget)
        self.groupbox2.setGeometry(QtCore.QRect(450, 150, 301, 391))
        self.groupbox2.setTitle("")
        self.groupbox2.setObjectName("groupbox2")
        self.label8 = QtWidgets.QLabel(self.groupbox2)
        self.label8.setGeometry(QtCore.QRect(30, 20, 71, 20))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.label8.setFont(font)
        self.label8.setObjectName("label8")
        self.list2 = QtWidgets.QListWidget(self.groupbox2)
        self.list2.setGeometry(QtCore.QRect(20, 50, 256, 321))
        self.list2.setObjectName("list2")
        self.text7 = QtWidgets.QLabel(self.groupbox2)
        self.text7.setGeometry(QtCore.QRect(110, 20, 171, 16))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.text7.setFont(font)
        self.text7.setObjectName("text7")
        self.text1 = QtWidgets.QLabel(self.centralwidget)
        self.text1.setGeometry(QtCore.QRect(110, 40, 47, 13))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.text1.setFont(font)
        self.text1.setObjectName("text1")
        self.text2 = QtWidgets.QLabel(self.centralwidget)
        self.text2.setGeometry(QtCore.QRect(300, 40, 47, 13))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.text2.setFont(font)
        self.text2.setObjectName("text2")
        self.text3 = QtWidgets.QLabel(self.centralwidget)
        self.text3.setGeometry(QtCore.QRect(510, 40, 47, 13))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.text3.setFont(font)
        self.text3.setObjectName("text3")
        self.text4 = QtWidgets.QLabel(self.centralwidget)
        self.text4.setGeometry(QtCore.QRect(720, 40, 47, 13))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.text4.setFont(font)
        self.text4.setObjectName("text4")
        self.text5 = QtWidgets.QLabel(self.centralwidget)
        self.text5.setGeometry(QtCore.QRect(150, 110, 47, 13))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.text5.setFont(font)
        self.text5.setObjectName("text5")
        self.text6 = QtWidgets.QLabel(self.centralwidget)
        self.text6.setGeometry(QtCore.QRect(530, 110, 47, 13))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.text6.setFont(font)
        self.text6.setObjectName("text6")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 21))
        self.menubar.setObjectName("menubar")
        self.menuManage_Teams = QtWidgets.QMenu(self.menubar)
        self.menuManage_Teams.setObjectName("menuManage_Teams")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.actionNew_Team = QtWidgets.QAction(MainWindow)
        self.actionNew_Team.setObjectName("actionNew_Team")
        self.actionOpen_Team = QtWidgets.QAction(MainWindow)
        self.actionOpen_Team.setObjectName("actionOpen_Team")
        self.actionSave_Team = QtWidgets.QAction(MainWindow)
        self.actionSave_Team.setObjectName("actionSave_Team")
        self.actionEvaluate_Team = QtWidgets.QAction(MainWindow)
        self.actionEvaluate_Team.setObjectName("actionEvaluate_Team")
        self.menuManage_Teams.addAction(self.actionNew_Team)
        self.menuManage_Teams.addAction(self.actionOpen_Team)
        self.menuManage_Teams.addAction(self.actionSave_Team)
        self.menuManage_Teams.addAction(self.actionEvaluate_Team)
        self.menubar.addAction(self.menuManage_Teams.menuAction())

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        
        self.rb1.toggled.connect(self.display_list)
        self.rb2.toggled.connect(self.display_list)
        self.rb3.toggled.connect(self.display_list)
        self.rb4.toggled.connect(self.display_list) 
        self.list1.itemDoubleClicked.connect(self.add_player)
        self.list2.itemDoubleClicked.connect(self.remove_player)
        self.menuManage_Teams.triggered[QtWidgets.QAction].connect(self.dropdown_menu)
        


    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label1.setText(_translate("MainWindow", "Your Selections"))
        self.label2.setText(_translate("MainWindow", "Batsmen (BAT)"))
        self.label3.setText(_translate("MainWindow", "Bowlers(BOW)"))
        self.label4.setText(_translate("MainWindow", "ALL Rounders(AR)"))
        self.label5.setText(_translate("MainWindow", "Wicket Keepers(WK)"))
        self.label6.setText(_translate("MainWindow", "Points Available"))
        self.label7.setText(_translate("MainWindow", "Points Used"))
        self.rb1.setText(_translate("MainWindow", "BAT"))
        self.rb2.setText(_translate("MainWindow", "BOW"))
        self.rb3.setText(_translate("MainWindow", "AR"))
        self.rb4.setText(_translate("MainWindow", "WK"))
        self.label8.setText(_translate("MainWindow", "Team Name"))
        self.text7.setText(_translate("MainWindow", "###"))
        self.text1.setText(_translate("MainWindow", "##"))
        self.text2.setText(_translate("MainWindow", "##"))
        self.text3.setText(_translate("MainWindow", "##"))
        self.text4.setText(_translate("MainWindow", "##"))
        self.text5.setText(_translate("MainWindow", "###"))
        self.text6.setText(_translate("MainWindow", "###"))
        self.menuManage_Teams.setTitle(_translate("MainWindow", "Manage Teams"))
        self.actionNew_Team.setText(_translate("MainWindow", "New Team"))
        self.actionOpen_Team.setText(_translate("MainWindow", "Open Team"))
        self.actionSave_Team.setText(_translate("MainWindow", "Save Team"))
        self.actionEvaluate_Team.setText(_translate("MainWindow", "Evaluate Team"))

    def display_list(self):
        #print("display list running")
        if self.rb1.isChecked()==True:
            category='BAT'
        if self.rb2.isChecked()==True:
            category='BOW'
        if self.rb3.isChecked()==True:
            category='AR'
        if self.rb4.isChecked()==True:
            category='WK'
        if self.text7.text()=='###':
            self.dialogue("Create/Open Team First")
            
        else:
            self.list1.clear()
            sql="SELECT player from Players where category='"+category+"';"
            cur=conn.execute(sql)
            list2_items=[]
            for i in range(self.list2.count()):
                    list2_items.append(self.list2.item(i).text())
            for row in cur:
                if row[0] not in list2_items:
                    self.list1.addItem(row[0])

    def dialogue(self,message):
        #print("dialogue running")
        Dialog=QtWidgets.QMessageBox()
        Dialog.setText(message)
        Dialog.setWindowTitle("Fantasy Cricket")
        ret=Dialog.exec()

    
    def dropdown_menu(self,action):
        #print("dropdown menu running")
        if action.text()=='New Team':
            self.bat,self.bow,self.ar,self.wk,self.avail,self.used=0,0,0,0,1000,0
            self.list1.clear()
            self.list2.clear()
            inp, ok = QtWidgets.QInputDialog.getText(MainWindow, "New Team", "Enter the name of your Team:")
            cur=conn.execute("Select * from Teams where name='"+inp+"'")
            row=cur.fetchone()
            if row:
                self.dialogue("A team with this name already exists")
            else:
                if ok:
                    self.text7.setText(inp)
                    self.display()
    
        if action.text()=='Open Team':
            sql="select * from Teams;"
            cur=conn.execute(sql)
            names=[]
            teams=[]
            players=[]
            for row in cur:
                names.append(row[0])
                teams.append([row[0],row[1],row[2],row[3],row[4],row[5],row[6]])

            inp, ok=QtWidgets.QInputDialog.getItem(MainWindow,"Open Team","Choose a team from below",names,0,False)
            if ok:
                self.text7.setText(inp)
                for team in teams:
                    if team[0]==inp:
                        players=row[1].split(',')
                        self.list2.addItems(players)
                        self.bat=team[3]
                        self.bow=team[4]
                        self.ar=team[5]
                        self.wk=team[6]
                        self.avail=1000-team[2]
                        self.used=team[2]
                        self.display()
                        
                        
                        
        if action.text()=='Save Team':
            num=self.list2.count()
            if self.text7.text()=="###":
                self.dialogue("Create/Open Team First")
                return
            if num!=11:
                message="Number of Players should be 11, you selected "+str(num)
                self.dialogue(message)
    
            else:
                players=""
                message=""
                for i in range(num):
                    players= players+ self.list2.item(i).text()+","
                #print("players=",players)
                players=players[:-1]
                cur=conn.execute("Select * from Teams where name='"+self.text7.text()+"'")
                row=cur.fetchone()
                if row!=None:
                    conn.execute("Delete from Teams where name='"+self.text7.text()+"'")
                    conn.commit()
                    message="Changes saved successfully"

                conn.execute("Insert into Teams (name,players,value,batsmen,bowlers,allrounders,wkeepers) VALUES (?,?,?,?,?,?,?)",(self.text7.text(),players,self.used,self.bat,self.bow,self.ar,self.wk))
                conn.commit()
                if message=="":
                    message="Team saved successfully"
                    
                self.dialogue(message)
                self.bat,self.bow,self.ar,self.wk,self.avail,self.used=0,0,0,0,1000,0
                self.list1.clear()
                self.list2.clear()
                self.text1.setText("##")
                self.text2.setText("##")
                self.text3.setText("##")
                self.text4.setText("##")
                self.text5.setText("###")
                self.text6.setText("###")
                self.text7.setText("###")

                
        if action.text()=='Evaluate Team':
            from window22 import Ui_Dialog
            Dialog = QtWidgets.QDialog()
            ui = Ui_Dialog()
            ui.setupUi(Dialog)
            ret=Dialog.exec()

    def add_player(self,item):
        #print("player to add = ",item.text())
        flag=True
        if self.rb1.isChecked()==True: category="BAT"
        if self.rb2.isChecked()==True: category="BOW"
        if self.rb3.isChecked()==True: category="AR"
        if self.rb4.isChecked()==True: category="WK"
    
        if category=="BAT" and self.bat==5:
            flag=False
            message="Number of batsmen cannot be more than 5"
        if category=="BOW" and self.bow==4:
            flag=False
            message="Number of bowlers cannot be more than 4"
        if category=="AR" and self.ar==2:
            flag=False
            message="Number of all-rounders cannot be more than 2"
        if category=="WK" and self.wk==1:
            flag=False
            message="Number of wicket-keepers cannot be more than 1"

    
        if flag==False:
            self.dialogue(message)
        else:
            sql="Select value from Players where player='"+item.text()+"'"
            cur=conn.execute(sql)
            row=cur.fetchone()
            val=int(row[0])
            if val<=int(self.avail):
                self.list1.takeItem(self.list1.row(item))
                self.list2.addItem(item.text())
                if category=="BAT":
                    self.bat=self.bat+1
                if category=="BOW":
                    self.bow=self.bow+1
                if category=="AR":
                    self.ar=self.ar+1
                if category=="WK":
                    self.wk=self.wk+1
                self.used=self.used+val
                self.avail=self.avail-val
                self.display()
            else:
                message="You don't have enough points to select this player"
                self.dialogue(message)
        
    def remove_player(self,item):
        #print("player to be removed",item.text())
        self.list2.takeItem(self.list2.row(item))
        sql="Select player,value,category from Players where player='"+item.text()+"'"
        cur = conn.execute(sql)
        row=cur.fetchone()
        category=row[2]
        
        self.avail=self.avail+int(row[1])
        self.used=self.used-int(row[1])
        if category=="BAT":
            self.bat=self.bat-1
            if self.rb1.isChecked()==True:
                self.list1.addItem(item.text())
        if category=="BOW":
            self.bow=self.bow-1
            if self.rb2.isChecked()==True:
                self.list1.addItem(item.text())
        if category=="AR":
            self.ar=self.ar-1
            if self.rb3.isChecked()==True:
                self.list1.addItem(item.text())
        if category=="WK":
            self.wk=self.wk-1
            if self.rb4.isChecked()==True:
                self.list1.addItem(item.text())
        self.display()

        

            
    def display(self):
        #print("display running")
        self.text1.setText(str(self.bat))
        self.text2.setText(str(self.bow))
        self.text3.setText(str(self.ar))
        self.text4.setText(str(self.wk))
        self.text5.setText(str(self.avail))
        self.text6.setText(str(self.used))
    


if __name__ == "__main__":
    conn = sqlite3.connect('Fantasy_cricket.db')
    #print("connected")
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
