# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'window22.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
import sqlite3
import sys

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        conn = sqlite3.connect('Fantasy_cricket.db')
        #print("connected")
        Dialog.setObjectName("Dialog")
        Dialog.resize(400, 300)
        self.label1 = QtWidgets.QLabel(Dialog)
        self.label1.setGeometry(QtCore.QRect(80, 0, 231, 20))
        self.label1.setObjectName("label1")
        self.box1 = QtWidgets.QComboBox(Dialog)
        self.box1.setGeometry(QtCore.QRect(80, 30, 91, 22))
        self.box1.setObjectName("box1")
        self.box2 = QtWidgets.QComboBox(Dialog)
        self.box2.setGeometry(QtCore.QRect(230, 30, 81, 22))
        self.box2.setObjectName("box2")
        self.line = QtWidgets.QFrame(Dialog)
        self.line.setGeometry(QtCore.QRect(50, 50, 301, 16))
        self.line.setFrameShape(QtWidgets.QFrame.HLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line.setObjectName("line")
        self.label2 = QtWidgets.QLabel(Dialog)
        self.label2.setGeometry(QtCore.QRect(60, 70, 47, 13))
        self.label2.setObjectName("label2")
        self.list1 = QtWidgets.QListWidget(Dialog)
        self.list1.setGeometry(QtCore.QRect(60, 90, 121, 171))
        self.list1.setObjectName("list1")
        self.label3 = QtWidgets.QLabel(Dialog)
        self.label3.setGeometry(QtCore.QRect(220, 70, 47, 13))
        self.label3.setObjectName("label3")
        self.label4 = QtWidgets.QLabel(Dialog)
        self.label4.setGeometry(QtCore.QRect(260, 70, 47, 13))
        self.label4.setObjectName("label4")
        self.list2 = QtWidgets.QListWidget(Dialog)
        self.list2.setGeometry(QtCore.QRect(220, 90, 121, 171))
        self.list2.setObjectName("list2")
        self.button = QtWidgets.QPushButton(Dialog)
        self.button.setGeometry(QtCore.QRect(160, 270, 91, 23))
        self.button.setObjectName("button")
       
        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
        
        rows=conn.execute("Select name from Teams")
        for row in rows:
            self.box1.addItem(row[0])
        self.box2.addItem("Match 1")
        self.button.clicked.connect(self.calculate_score)
        
    def retranslateUi(self, Dialog):
        #print("restranslate2 running")
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.label1.setText(_translate("Dialog", "Evalute the Performance of your Fantasy Team "))
        self.label2.setText(_translate("Dialog", "Players"))
        self.label3.setText(_translate("Dialog", "Points"))
        self.label4.setText(_translate("Dialog", "##"))
        self.button.setText(_translate("Dialog", "Calculate Score"))

    def calculate_score(self):
        #print("calculate score running")
        conn1 = sqlite3.connect('Fantasy_cricket.db')
        self.list1.clear()
        self.list2.clear()
        team = self.box1.currentText()
        row=conn1.execute("Select * from Teams where name='"+team+"'")
        row=row.fetchone()
        players=row[1].split(",")
        scores=[]
        val=0
        #print("players",players)
        for i in range(11):
            row=conn1.execute("Select * from Players where player='"+players[i]+"'")
            row=row.fetchone()
            score=0
            score= score + row[1]/2
            if row[1]>=50:
                score = score+5
            if row[1]>=100:
                score = score+10
            if row[1]>0 and (row[1]*100)/row[2] >100:
                score = score+4
            if row[1]>0 and ((row[1]*100)/row[2] >=80 and (row[1]*100)/row[2] <=100):
                score = score+2
            score = score+ (row[3]*1) + (row[4]*2) + (row[8]*10)
            if row[8]>=3:
                score = score+5
            if row[8]>=5:
                score = score+10
            if row[5]>0 and (row[7]/(row[5]/6) >= 3.5 and row[7]/(row[5]/6)<=4.5):
                score = score+4
            if row[5]>0 and (row[7]/(row[5]/6) >= 2 and row[7]/(row[5]/6)<3.5):
                score = score+7
            if row[5]>0 and row[7]/(row[5]/6)<2:
                score = score+10
            score = score + (row[9]*10) + (row[10]*10) + (row[11]*10)
            scores.append(str(int(score)))
            val=val+int(score)
       
        self.list1.addItems(players)
        self.list2.addItems(scores)
        self.label4.setText(str(val))

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())

